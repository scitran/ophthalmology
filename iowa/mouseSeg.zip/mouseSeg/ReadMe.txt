Requirements
  - OS: Windows (x64)
  - Memory: 48 GB
  - Visual C++ Redistributable for Visual Studio 2015 (vc_redist.x64.exe, 13.9 MB): https://www.microsoft.com/en-us/download/details.aspx?id=48145
  
Supporting OCT
   - Bioptigen OCT (400x1024x400 voxels, .OCT)

Usage
  1. mouseSeg.exe Bioptigen.OCT Surfaces3.xml
  2. XMLConverter4.exe Surfaces3.xml Surfaces4.xml
    - Surfaces4.xml: final output

Visualization and analysis tool: OCTExplorer 3.8.0
